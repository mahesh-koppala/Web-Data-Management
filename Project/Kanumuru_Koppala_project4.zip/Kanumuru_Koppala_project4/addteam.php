<?php

if (isset($_POST['sub'])) {
	register();
}

if (isset($_POST['delete'])) {
	delete();
}

if (isset($_POST['edit'])) {
	edit();
}

function register(){

/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Team_Name'];
$email = $_POST['User_Id'];
$contact = $_POST['Project_Id'];

 
// Attempt insert query execution
$sql = "INSERT INTO teams(team_name,u_id,p_id) VALUES
('$name','$email','$contact')";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}




function delete()
{
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Team_Name'];
$email = $_POST['User_Id'];
$contact = $_POST['Project_Id'];

 
// Attempt insert query execution
$sql = "DELETE FROM teams WHERE team_name= '$name'" ;
if(mysqli_query($link, $sql)){
    echo "Records deleted successfully.";
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

}


function edit()
{
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Team_Name'];
$email = $_POST['User_Id'];
$contact = $_POST['Project_Id'];
 
// Attempt insert query execution
$sql = "UPDATE teams SET u_id='$email', p_id='$contact' WHERE team_name= '$name'" ;
if(mysqli_query($link, $sql)){
    echo "Records edited successfully.";
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

}





