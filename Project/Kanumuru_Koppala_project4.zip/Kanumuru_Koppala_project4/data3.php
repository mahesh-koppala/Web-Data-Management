<?php
$conn = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
$result = mysqli_query($conn, "SELECT * FROM teams");

$data = array();
while ($row = mysqli_fetch_object($result))
{
    array_push($data, $row);
}

echo json_encode($data);
exit();