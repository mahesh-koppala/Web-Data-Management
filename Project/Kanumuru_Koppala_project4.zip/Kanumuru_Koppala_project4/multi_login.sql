
INSERT INTO `users` (`id`, `username`, `email`, `user_type`, `password`) VALUES
(1, 'admin', 'adi10.patil@gmail.com', 'admin', 'admin'),
(2, 'id', 'id', 'admin', 'id'),
(3, 'admin', 'adi@gmail.com', 'admin', 'f6fdffe48c908deb0f4c3bd36c032e72'),
(4, 'admin', 'adi@gmail.com', 'admin', 'f6fdffe48c908deb0f4c3bd36c032e72'),
(5, 'user', 'adit2patil@gmail.com', 'user', '5cc32e366c87c4cb49e4309b75f57d64'),
(6, 'user', 'adit2patil@gmail.com', 'user', '5cc32e366c87c4cb49e4309b75f57d64');

CREATE TABLE users( id INT(10) PRIMARY KEY, user_name VARCHAR(25), email VARCHAR(25), user_type varchar(100) NOT NULL, password varchar(100) NOT NULL);

CREATE TABLE events ( event_id VARCHAR(9) PRIMARY KEY, event_name VARCHAR(25), event_description VARCHAR(25),e_user_id INT(10), FOREIGN KEY (e_user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE ) ENGINE = INNODB;

CREATE TABLE project ( project_id VARCHAR(9) PRIMARY KEY, project_title VARCHAR(25), project_description VARCHAR(25),project_purpose VARCHAR(25),p_user_id INT(25), FOREIGN KEY (p_user_id) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE );

CREATE TABLE teams ( team_name VARCHAR(25) PRIMARY KEY, u_id INT(10), p_id VARCHAR(25));

CREATE TABLE videos ( video_id VARCHAR(9) PRIMARY KEY, video_title VARCHAR(25), link_url VARCHAR(45),v_event_id VARCHAR(25), FOREIGN KEY (v_event_id) REFERENCES events(event_id) ON DELETE CASCADE ON UPDATE CASCADE );


INSERT INTO users(id,user_name,email,user_type,password) VALUES
(7013,'rahul','rahul@mavs.uta.edu','developer','pass123'),
(7014,'mahesh','mahesh@mavs.uta.edu','tester','pass456'),
(7015,'varsha','varsha@mavs.uta.edu','analyst','pass789');

INSERT INTO events(event_id,event_name,event_description,e_user_id) VALUES
('ev_rk','rahul_event','events about books',7013),
('ev_mk','mahesh_event','events about movies',7014),
('ev_va','varha_event','events about songs',7015);

INSERT INTO project(project_id,project_title,project_description,project_purpose,p_user_id) VALUES
('p_rk','rahul_project','projects about books','books_price_increase',7013),
('p_mk','mahesh_project','projects about movies','movie_piracy',7014),
('p_ak','varsha_project','projects about songs','songs_download illegal',7015);

INSERT INTO teams(team_name,u_id,p_id) VALUES
('rahul_rockers','100','p_r'),
('mahesh_massives','101','p_m'),
('varsha_valleys','102','p_v');


INSERT INTO videos(video_id,video_title,link_url,v_event_id) VALUES
('v01','rahul_video','https://youtu.be/g-VweGjYLEQ','ev_rk'),
('v02','mahesh_video','https://youtu.be/3ZT4Qe41SPc','ev_mk'),
('v03','varsha_video','https://youtu.be/fLexgOxsZu0','ev_va');