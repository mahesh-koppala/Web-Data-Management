
<?php

if (isset($_POST['sub'])) {
	register();
}

if (isset($_POST['delete'])) {
	delete();
}

if (isset($_POST['edit'])) {
	edit();
}


/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
function register(){
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Project_Id'];
$email = $_POST['Project_Title'];
$contact = $_POST['Project_Description'];
$address = $_POST['Project_Purpose'];
$address2 = $_POST['P_user_Id'];
 
// Attempt insert query execution
$sql = "INSERT INTO project(project_id,project_title,project_description,project_purpose,p_user_id) VALUES
('$name','$email','$contact','$address',$address2)";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}

function delete()
{
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Project_Id'];
$email = $_POST['Project_Title'];
$contact = $_POST['Project_Description'];
$address = $_POST['Project_Purpose'];
$address2 = $_POST['P_user_Id'];
 
// Attempt insert query execution
$sql = "DELETE FROM project WHERE project_id= '$name'" ;
if(mysqli_query($link, $sql)){
    echo "Records deleted successfully.";
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

}



function edit()
{
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Project_Id'];
$email = $_POST['Project_Title'];
$contact = $_POST['Project_Description'];
$address = $_POST['Project_Purpose'];
$address2 = $_POST['P_user_Id'];
 
// Attempt insert query execution
$sql = "UPDATE project SET project_title='$email', project_description='$contact',project_purpose='$address' WHERE project_id= '$name'" ;
if(mysqli_query($link, $sql)){
    echo "Records edited successfully.";
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

}