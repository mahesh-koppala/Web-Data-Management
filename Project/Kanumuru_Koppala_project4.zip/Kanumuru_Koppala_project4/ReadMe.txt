Names : Rahul Kanumuru - 1001738833

Mahesh Kopplala - 1001764522



Please Note : The path to theimages is updated according to the uta cloud.



UTA Cloud : https://rxk8833.uta.cloud/Kanumuru_Koppala_project2/HomePage.html 
Path to CLoud folder.


UTA Cloud : https://rxk8833.uta.cloud/Kanumuru_Koppala_project2/blog.html
Path to Cloud folder.


Screenshots of the email for registration page have been given in the folder as image0 and image1.