<?php

if (isset($_POST['sub'])) {
	register();
}

if (isset($_POST['delete'])) {
	delete();
}


if (isset($_POST['edit'])) {
	edit();
}

function register(){

/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Event_Id'];
$email = $_POST['Event_Name'];
$contact = $_POST['Event_Description'];
$address = $_POST['E_User_ID'];
 
// Attempt insert query execution
$sql = "INSERT INTO events(event_id,event_name,event_description,e_user_id) VALUES
('$name','$email','$contact','$address')";
if(mysqli_query($link, $sql)){
    echo "Records inserted successfully.";
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
}


function delete()
{
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Event_Id'];
$email = $_POST['Event_Name'];
$contact = $_POST['Event_Description'];
$address = $_POST['E_User_ID'];
 
// Attempt insert query execution
$sql = "DELETE FROM events WHERE event_id= '$name'" ;
if(mysqli_query($link, $sql)){
    echo "Records deleted successfully.";
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

}


function edit()
{
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$link = mysqli_connect("localhost", "rxk8833_rahul", "rahulks@14", "rxk8833_multi_login");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
$name = $_POST['Event_Id'];
$email = $_POST['Event_Name'];
$contact = $_POST['Event_Description'];
$address = $_POST['E_User_ID'];
 
// Attempt insert query execution
$sql = "UPDATE events SET event_name='$email', event_description='$contact', e_user_id='$address' WHERE event_id= '$name'" ;
if(mysqli_query($link, $sql)){
    echo "Records edited successfully.";
    
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}

}


