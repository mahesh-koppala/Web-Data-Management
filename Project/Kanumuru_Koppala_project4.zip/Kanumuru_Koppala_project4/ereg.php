<!DOCTYPE html>
<html lang="en">
  <head><meta charset="windows-1252">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Dynamic</title>
    <link rel="stylesheet" href="css/mijares.css" />
   <link
      href="https://fonts.googleapis.com/css?family=Montserrat&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="js/Mijares.js" type="text/javascript"></script>
  </head>
  <body>
      <nav>
      <ul>
        <button>🞬</button>
       <li style="padding-right: 12%"><a href="#home"> <img
      src="https://rxk8833.uta.cloud/Kanumuru_Koppala_project2/imgs/logo.png"
      style="position: absolute; top: 0px;left : 75px; right: 0; width: 50 px; height: 120px "
      alt="Avatar"
    />  </a></li>
       <li><a href="HomePage.html">Inicio</a></li>
        <li><a href="Semblanza.html">Semblanza</a></li>
        <li><a href="Centro_Augusto_Mijares.html"> Centro Augusto Mijares</a></li>
        <li><a href="Proyectos.html">Proyectos</a></li>
        <li><a href="Eventos.html">Eventos</a></li>
        <li><a href="blog.html">Blog</a></font></li>
        <li><a href="Videos.html">Videos</a></li>
        <li><a href="Equipo.html">Equipo</a></li>
        <li><a href="UserCenter.html">UserCenter</a></li>
      </ul>
    </nav>
    <header><h1 style="text-align: center">Dynamic</h1></header>
    <div class="wrapper-blog">
     <div>
  <form action="add.php" method="post">
  
 <h2 align="center"> ADD PROJECT </h2>
  
    <label for="Project_Id">Project_Id</label>
    <input type="text" id="Project_Id" name="Project_Id" placeholder="Your Project_Id.." required>

    <label for="Project_Title">Project_Title</label>
    <input type="text" id="Project_Title" name="Project_Title" placeholder="Your Project_Title.." required>

    <label for="Project_Description">Project_Description</label>
    <input type="text" id="Project_Description" name="Project_Description" placeholder="Your Project_Description.." required>
    
    <label for="Project_Purpose">Project_Purpose</label>
    <input type="text" id="Project_Purpose" name="Project_Purpose" placeholder="Your Project_Purpose.." required>
    
    <label for="P_user_Id">P_user_Id</label>
    <input type="text" id="P_user_Id" name="P_user_Id" placeholder="Your P_user_Id.." required>
    
  
    <input type="submit" value="Submit" name = "sub">
    <input type="submit" value="Delete" name = "delete">
     <input type="submit" value="Edit" name = "edit">
     
  </form>
  
  
  
</div>

    </div>
    <div class="wrapper-blog">
      <div>
  <form action="addevent.php" method="post">
  <h2 align="center"> ADD EVENT </h2>
  
    <label for="Event_Id">Event_Id</label>
    <input type="text" id="Event_Id" name="Event_Id" placeholder="Your Event_Id..">

    <label for="Event_Name">Event_Name</label>
    <input type="text" id="Event_Name" name="Event_Name" placeholder="Your Event_Name..">

  <label for="Event_Description">Event_Description</label>
    <input type="text" id="Event_Description" name="Event_Description" placeholder="Your Event_Description..">
    
    <label for="E_User_ID">E_User_ID</label>
    <input type="text" id="E_User_ID" name="E_User_ID" placeholder="Your E_User_ID..">
  
    <input type="submit" value="Submit" name = "sub">
    <input type="submit" value="Delete" name = "delete">
       <input type="submit" value="Edit" name = "edit">
  </form>
</div>

      </div>
    </div>
    
    
    <div class="wrapper-blog">
      <div>
  <form action="addteam.php" method="post">
  <h2 align="center"> ADD TEAM </h2>
    <label for="Team_Name">Team_Name</label>
    <input type="text" id="Team_Name" name="Team_Name" placeholder="Your Team_Name..">

    <label for="User_Id">User_Id</label>
    <input type="text" id="User_Id" name="User_Id" placeholder="Your User_Id..">

    <label for="Project_Id">Project_Id</label>
    <input type="text" id="Project_Id" name="Project_Id" placeholder="Your Project_Id..">
  
    <input type="submit" value="Submit" name = "sub">
    <input type="submit" value="Delete" name = "delete">
       <input type="submit" value="Edit" name = "edit">
  </form>
</div>

      </div>
         <div>
  <form action="addvideo.php" method="post">
  <h2> ADD VIDEO </h2>
    <label for="Video_Id">Video_Id</label>
    <input type="text" id="Video_Id" name="Video_Id" placeholder="Your Video_Id..">

    <label for="Video_Title">Video_Title</label>
    <input type="text" id="Video_Title" name="Video_Title" placeholder="Your Video_Title..">

    <label for="Link_Url">Link_Url</label>
    <input type="text" id="Link_Url" name="Link_Url" placeholder="Your Link_Url..">
    
    <label for="V_Event_Id">V_Event_Id</label>
    <input type="text" id="V_Event_Id" name="V_Event_Id" placeholder="Your V_Event_Id..">
  
    <input type="submit" value="Submit" name = "sub">
    <input type="submit" value="Delete" name = "delete">
       <input type="submit" value="Edit" name = "edit">
  </form>
</div>
    </div>
    <!-- Log in popup starts -->
    <!-- The Modal -->
    <div id="id01" class="modal">
      <span
        onclick="document.getElementById('id01').style.display='none'"
        class="close"
        title="Close Modal"
        >&times;</span
      >

      <!-- Modal Content -->
      <form class="modal-content animate" action="/action_page.php">
        <div style="padding: 2%">
          <h1>Log in</h1>
        </div>

        <div class="container">
          <label for="uname"><b>Username</b></label>
          <input
            type="text"
            placeholder="Enter Username"
            name="uname"
            required
          />

          <label for="psw"><b>Password</b></label>
          <input
            type="password"
            placeholder="Enter Password"
            name="psw"
            required
          />

          <button type="submit">Login</button>
          <label>
            <input type="checkbox" checked="checked" name="remember" /> Remember
            me
          </label>
        </div>

        <div class="container" style="background-color:#f1f1f1">
          <button
            type="button"
            onclick="document.getElementById('id01').style.display='none'"
            class="cancelbtn"
          >
            Cancel
          </button>
          <span class="psw">Forgot <a href="#">password?</a></span>
        </div>
      </form>
    </div>
    <!-- Log in popup ends -->
    <!-- The Modal -->
    <div id="id02" class="modal">
      <span
        onclick="document.getElementById('id02').style.display='none'"
        class="close"
        title="Close Modal"
        >&times;</span
      >

      <!-- Modal Content -->
      <form class="modal-content animate" action="/action_page.php">
        <div style="padding: 2%">
          <h1>Check in</h1>
        </div>

        <div class="container">
          <label for="name"><b>Name</b></label>
          <input type="text" placeholder="Enter name" name="name" required />

          <label for="lname"><b>Last name</b></label>
          <input
            type="text"
            placeholder="Enter Last name"
            name="lname"
            required
          />
          <label for="email"><b>Email</b></label>
          <input type="text" placeholder="Enter Email" name="email" required />
          <label for="usern"><b>Username</b></label>
          <input
            type="password"
            placeholder="Enter Password"
            name="usern"
            required
          />
          <label for="pass"><b>Password</b></label>
          <input
            type="password"
            placeholder="Enter Password"
            name="pass"
            required
          />
          <label for="rpass"><b>Repeat Password</b></label>
          <input
            type="password"
            placeholder="Reenter Password"
            name="rpass"
            required
          />

          <button type="submit">Save</button>
        </div>

        <div class="container" style="background-color:#f1f1f1">
          <button
            type="button"
            onclick="document.getElementById('id02').style.display='none'"
            class="cancelbtn"
          >
            Cancel
          </button>
        </div>
      </form>
    </div>
     
  </body>
</html>